<template>
    <div id="Revisiones">
        <p id="titulo">Revisiones: {{ nombrerestoran }}</p>
        <p class="verde">Hola bienvenidos a nuestra página de restoran</p>
        <p class="verde">Gracias por preferir nuestra página</p>
    </div>
</template>

<script>
    export default {
        name:'Revisiones',
        props:{
            nombrerestoran:String
        }
    }
</script>

<style scoped>
    #Revisiones{
        font-size:35px;
        margin:20px;
    }
    #titulo{
        color:blue;
    }
    .verde{
        color:green;
    }
</style>