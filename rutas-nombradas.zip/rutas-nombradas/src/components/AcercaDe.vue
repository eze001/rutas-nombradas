<template>
    <div id="AcercaDe">
        <p id="titulo">sobre: {{ nombrerestoran }}</p>
        <p>No tenemos información sobre este restoran en este momento</p>
        <img id="dibujorestoran" src="./restoran.jpg" alt="dibujo">
    </div>
</template>

<script>
    export default {
        name: 'AcercaDe',
        props:{
            nombrerestoran:String,
        }
    }
</script>


<style scoped>
    #titulo{
        margin-left:40px;
        font-size:40px;
    }
    p{
        font-family:calibri;
    }
    #dibujorestoran{
        margin:30px;
        width:400px;
        height:300px;
        display:block;
    }
</style>