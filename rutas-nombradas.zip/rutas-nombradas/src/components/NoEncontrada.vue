<template>
    <div id="NoEncontrada">
        <h2>Error 404: Pagina no encontrada</h2>
    </div>
</template>

<script>
    export default{
        name:'NoEncontrada'
    }
</script>

<style scoped>
    #NoEncontrada{
        margin:20px;
        font-size:40px;
    }
</style>