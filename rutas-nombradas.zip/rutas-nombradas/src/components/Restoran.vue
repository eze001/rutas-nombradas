<template>
    <div id="Restoran">
        <router-link id="acercade" v-bind:to="{name:'acercade'}">AcercaDe</router-link>
        <router-link id="revisiones" v-bind:to="{name:'revisiones'}">Revisiones</router-link>
        <router-link id="imagenes" v-bind:to="{name:'imagenes'}">Imagenes</router-link>
        <!--reviews
        'images'-->
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: 'Restoran',
        props:{
            nombrerestoran:String,
        }
    }
</script>

<style scoped>
    #Restoran{
        margin-top:10px;
    }
    #acercade,#revisiones,#imagenes{
        margin:10px;
    }
</style> 