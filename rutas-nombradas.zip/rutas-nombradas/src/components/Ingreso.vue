<template>
    <div id="Ingreso">
        <h2>Iniciar Sesión</h2>
        <div class="c1">
            <p>Usuario: </p><input type="text">
        </div>
        <div class="c1">
            <p>Contraseña: </p><input type="text">
        </div>
        <button>Iniciar Sesión</button>
    </div>
</template>

<script>
    export default{
        name:'Ingreso'
    }
</script>

<style scoped>
    #Ingreso{
        font-size:25px;
        margin:20px;
    }
    p,input{
        display:inline-block;
        vertical-align:top;
    }
    input{
        height:30px;
        margin-left:10px;
        margin-top:20px;
        font-size:20px;
    }
    .c1{
        display:block;
    }
</style>